# Portfólio — Guilherme Nuncio

Site estático em HTML, CSS e imagem local.

## Publicar no GitHub Pages
1. Extraia os arquivos deste pacote.
2. Envie `index.html` e a pasta `assets/` para a raiz do repositório `Guilhermehenriquee/guilhermehbgn`.
3. No GitHub, abra **Settings → Pages** e configure a publicação a partir da branch principal e da pasta `/ (root)`, se ainda não estiver configurado.

A imagem de perfil é carregada de `assets/guilherme-nuncio.png`; mantenha essa estrutura de pastas. O botão de currículo aponta para `CV_Guilherme_Henrique.pdf`, então adicione esse PDF à raiz se quiser manter o download funcionando.
